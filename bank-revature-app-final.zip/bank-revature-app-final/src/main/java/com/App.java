package com;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	System.out.println("**************** Welcome to NSSDA Banking App *******************");
        BankApp bankApp = new BankApp();
        bankApp.startBankApp();
    }
}
